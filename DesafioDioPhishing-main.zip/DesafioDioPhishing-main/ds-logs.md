# Estrutura do Arquivo de Log: 

O que pode ser salvo em logs/resultados.txt: 


[*] Credential Harvester is running on http://192.168.1.100
[*] Waiting for data to be submitted...

[*] We got a hit! IP: 192.168.1.101
[*] User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36
[*] POST request received from: 192.168.1.101
[*] Data captured:
username=usuario_exemplo
password=senha_exemplo 


________________________________________


[*] We got a hit! IP: 192.168.1.102
[*] User-Agent: Mozilla/5.0 (Windows NT 10.0; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/84.0
[*] POST request received from: 192.168.1.102
[*] Data captured:
username=teste_user
password=senha123


_______________________________________



[*] We got a hit! IP: 192.168.1.103
[*] User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Safari/537.36
[*] POST request received from: 192.168.1.103
[*] Data captured:
username=usuario_teste
password=senha_secreta   






